export { default } from '../../src/components/employees/EmployeeCard';
