export const authOptions = { providers: [], session: { strategy: 'jwt' } };
